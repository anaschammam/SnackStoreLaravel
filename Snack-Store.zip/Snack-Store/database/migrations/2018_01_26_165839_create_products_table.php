<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProductsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('products', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name');
            $table->double('price', 8,2);
            $table->integer('amount');     
            $table->integer('likes')->nullable();   
            $table->string('image');                                                          
            $table->timestamps();
        });
        DB::table('products')->insert(array("id"=>'1',
        "name"=>"jelly donuts",
        "price"=>'1.15'
        ,"image"=>"https://www.seriouseats.com/recipes/images/2013/11/20131113-266257-crandonut8-edit.jpg"
        ,"amount" =>'30'
        ,"likes"=>'45'
        ,"created_at"=>'2018-01-31 07:13:44'
        ,"updated_at"=>'2018-01-31 07:13:48'),
            );
        DB::table('products')->insert(array("id"=>'2',
        "name"=>"lemon drops",
        "price"=>'2.50'
        ,"image"=>"https://images-na.ssl-images-amazon.com/images/I/81Auyw-Cl1L._SL1500_.jpg"
        ,"amount" =>'45'
        ,"likes"=>'0'
        ,"created_at"=>'2020-01-31 07:13:44'
        ,"updated_at"=>'2021-01-31 07:13:48'),
            );
DB::table('products')->insert(array("id"=>'3',
        "name"=>"Mister Bee Potatos",
        "price"=>'4.44'
        ,"image"=>"https://misterbee.com/wp-content/uploads/2018/08/mrbee_original.png"
        ,"amount" =>'50'
        ,"likes"=>'4'
        ,"created_at"=>'2020-01-31 07:13:44'
        ,"updated_at"=>'2021-01-31 07:13:48'),
            );
DB::table('products')->insert(array("id"=>'4',
        "name"=>"Vanilla pudding cups",
        "price"=>'2.22'
        ,"image"=>"https://i5.walmartimages.com/asr/53c0577b-b055-4cc2-b414-86a7dfba9f3f.901ba6cec12473c40303fca692783117.jpeg"
        ,"amount" =>'100'
        ,"likes"=>'7'
        ,"created_at"=>'2020-01-31 07:13:44'
        ,"updated_at"=>'2021-01-31 07:13:48'),
            );
DB::table('products')->insert(array("id"=>'5',
        "name"=>"Cheese popcorn",
        "price"=>'3.33'
        ,"image"=>"https://images-na.ssl-images-amazon.com/images/I/91Bo28EW7eL._SL1500_.jpg"
        ,"amount" =>'23'
        ,"likes"=>'7'
        ,"created_at"=>'2020-01-31 07:13:44'
        ,"updated_at"=>'2021-01-31 07:13:48'),
            );
DB::table('products')->insert(array("id"=>'6',
        "name"=>"long john",
        "price"=>'3.33'
        ,"image"=>"https://midnightdonuts.com.au/wp-content/uploads/2019/07/gaytime-long-johns.jpg"
        ,"amount" =>'22'
        ,"likes"=>'6'
        ,"created_at"=>'2020-01-31 07:13:44'
        ,"updated_at"=>'2021-01-31 07:13:48'),
            );
DB::table('products')->insert(array("id"=>'7',
        "name"=>"Chocolate Pudding cups",
        "price"=>'3.33'
        ,"image"=>"https://images-na.ssl-images-amazon.com/images/I/81MaOBUy3wL._SL1500_.jpg"
        ,"amount" =>'28'
        ,"likes"=>'2'
        ,"created_at"=>'2020-01-31 07:13:44'
        ,"updated_at"=>'2021-01-31 07:13:48'),
            );
DB::table('products')->insert(array("id"=>'8',
        "name"=>"Diced peaches",
        "price"=>'3.33'
        ,"image"=>"https://images-na.ssl-images-amazon.com/images/I/71ndJWGQ38L._SX679_PIbundle-6,TopRight,0,0_AA679SH20_.jpg"
        ,"amount" =>'100'
        ,"likes"=>'1'
        ,"created_at"=>'2020-01-31 07:13:44'
        ,"updated_at"=>'2021-01-31 07:13:48'),
            );
DB::table('products')->insert(array("id"=>'9',
        "name"=>"Graham crackers",
        "price"=>'2.30'
        ,"image"=>"https://images-na.ssl-images-amazon.com/images/I/81bOZci5qiL._SL1500_.jpg"
        ,"amount" =>'100'
        ,"likes"=>'1'
        ,"created_at"=>'2020-01-31 07:13:44'
        ,"updated_at"=>'2021-01-31 07:13:48'),
            ); 
DB::table('products')->insert(array("id"=>'10',
        "name"=>"tea",
        "price"=>' 9.99'
        ,"image"=>"https://images-na.ssl-images-amazon.com/images/I/910zOWRYVML._SX425_PIbundle-100,TopRight,0,0_AA425SH20_.jpg"
        ,"amount" =>'200'
        ,"likes"=>'10'
        ,"created_at"=>'2020-01-31 07:13:44'
        ,"updated_at"=>'2021-01-31 07:13:48'),
            ); 
DB::table('products')->insert(array("id"=>'11',
        "name"=>"Fruit grain bars",
        "price"=>'1.75'
        ,"image"=>"https://images-na.ssl-images-amazon.com/images/I/91WLZayy4pL._AC_SX679_.jpg"
        ,"amount" =>'200'
        ,"likes"=>'0'
        ,"created_at"=>'2020-01-31 07:13:44'
        ,"updated_at"=>'2021-01-31 07:13:48'),
            ); 
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('products');
    }
}
